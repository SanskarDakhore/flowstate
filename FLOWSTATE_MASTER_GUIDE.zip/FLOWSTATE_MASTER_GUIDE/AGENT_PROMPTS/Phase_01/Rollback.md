# Phase 01 Emergency Rollback Protocol

## Trigger Conditions
- UI changes introduce compilation errors that cannot be resolved within phase time budget.
- Unintended regression to movement physics or camera trajectory occurs.

## Recovery Steps
```powershell
# Reset modified UI files to last clean git commit
git checkout HEAD -- frontend/src/ui/

# Verify clean workspace state
npm run check
```
