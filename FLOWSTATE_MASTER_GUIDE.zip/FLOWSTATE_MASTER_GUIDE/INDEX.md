# FLOWSTATE Game Development Operating System (GDOS) v2.0

> **Master Architecture & Production Blueprint Index**  
> *Target Goal: Guide Antigravity IDE & Codex from Prototype to App Store / Play Store Production Release.*

---

## 1. Project Memory & Single Source of Truth
*Check these documents BEFORE executing any phase or making architectural decisions.*

- [DECISION_LOG.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/DECISION_LOG.md) — Recorded design & technical decisions.
- [CONFIRMED_FEATURES.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/CONFIRMED_FEATURES.md) — Locked features and mechanics.
- [EXPERIMENTAL_FEATURES.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/EXPERIMENTAL_FEATURES.md) — R&D ideas in testing.
- [REJECTED_IDEAS.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/REJECTED_IDEAS.md) — Design paths explicitly rejected to prevent re-work.
- [ARCHITECTURE_HISTORY.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/ARCHITECTURE_HISTORY.md) — Core engine & system evolution history.
- [CHANGELOG.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/99_PROJECT_MEMORY/CHANGELOG.md) — Complete GDOS & repository execution log.

---

## 2. Core Modules (38 Top-Level Specification Domains)

### Core & Philosophy
- [00_PROJECT_CORE/Vision.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Vision.md)
- [00_PROJECT_CORE/Core_Philosophy.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Core_Philosophy.md)
- [00_PROJECT_CORE/Design_Pillars.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Design_Pillars.md)
- [00_PROJECT_CORE/Technical_Principles.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Technical_Principles.md)
- [00_PROJECT_CORE/Architecture_Rules.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Architecture_Rules.md)
- [00_PROJECT_CORE/Coding_Standards.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Coding_Standards.md)
- [00_PROJECT_CORE/AI_Agent_Instructions.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/AI_Agent_Instructions.md)
- [00_PROJECT_CORE/Do_Not_Break_Rules.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Do_Not_Break_Rules.md)
- [00_PROJECT_CORE/Release_Quality_Standards.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/00_PROJECT_CORE/Release_Quality_Standards.md)

### Gameplay & Systems
- `01_GAMEPLAY/` — [Movement](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Movement/), [Physics](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Physics/), [Abilities](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Abilities/), [Scoring](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Scoring/), [Obstacles](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Obstacles/), [Enemy_Systems](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Enemy_Systems/), [Flow_Mechanics](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Flow_Mechanics/), [Risk_Reward](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Risk_Reward/), [Difficulty](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Difficulty/), [Tutorial](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Tutorial/), [Accessibility](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/01_GAMEPLAY/Accessibility/)

### Physics Engine
- `02_PHYSICS/` — Core, Player, Track, Environmental, Obstacles, Surfaces, Gravity, Moving Platforms, Wind, Water, Elastic, Energy, Collisions

### Level Design & World Generation
- `03_LEVEL_DESIGN/` — World Structure, Procedural Rules, Ribbon Generators, Curve Math, Slopes, Branches, Challenge Types, Game Modes

### Simulation & Living World
- `04_LIVING_WORLD_SIMULATION/` — Biomes, Ecosystem, Vegetation Simulation, Weather State Machine, Day/Night Cycle, Wildlife AI, Seasons, Resonance Growth

### Visuals & Environment Rendering
- `05_ENVIRONMENT_RENDERING/` — Terrain Splatting, Shaders, Grass GPU Instancing, Water Shader, Weather VFX, Volumetrics, HDR, Bloom, Atmosphere

### Art Direction & Styling
- `06_ART_DIRECTION/` — Color Language, PBR Materials, Lighting Setup, Particle FX, Camera FX, UI Aesthetics, Asset Import Rules

### Player Character (The Sphere)
- `07_PLAYER_SPHERE/` — Ball Physics, Evolution Stages, Material Layers, Trail Skins, Visual Auras, Customization Engine, Emotes

### Track System Specifications
- `08_TRACK_SYSTEM/` — Ribbon Architecture, Track Generation Math, Stability Specifications, Track Validation, Repair Specs, Integrity Rules

### Progression & Unlock Mechanics
- `09_PROGRESSION/` — XP System, Player Levels, Skill Rating, Mastery, Unlocks, Daily/Weekly Challenges, Prestige

### Perks & Customization
- `10_PERKS/` — Passive Perks, Active Perks, Upgrade Trees, Balance Matrix, Synergies

### Cosmetics & Economy
- `11_COSMETICS_ECONOMY/` — Ball Collection, World Themes, Cosmetic Rarity, Ethical Economy, Store Infrastructure

### Audio & Haptics Engine
- `12_AUDIO_ENGINE/` — Spatial Audio, Dynamic Resonance Music, Sound Effects, Haptic Feedback Engine, Audio Budgets

### UI / UX Architecture
- `13_UI_UX/` — HUD Architecture, DevPanel Isolation, CSS Token Discipline, Touch Inputs, Menu Systems, Motion Design

### Balance & Tuning
- `14_BALANCE/` — Difficulty Curves, XP Scaling, Score Formulas, Spawn Frequencies, Perk Retention Matrix

### Engine Architecture & Technical Core
- `15_TECHNICAL_ENGINE/` — Scene Graph, Memory Management, Object Pooling, Serialization, Input Router
- `16_SHADER_SYSTEM/` — HLSL/GLSL Material Shaders, Post-Processing Pipeline, Compute Shaders, Mobile Shaders
- `17_ASSET_PIPELINE/` — Asset Standards, Compression Rules, Naming Conventions, Import Settings, Texture Streaming
- `18_OPTIMIZATION_LOD/` — GPU Optimization, CPU Threading, Draw Call Minimization, VRAM Budgets, LOD Matrices

### Multiplayer, Cloud & Backend
- `19_SOCIAL_MULTIPLAYER/` — Leaderboards, Ghosts/Replays, Async Multiplayer, Seasonal Events, Friend Systems
- `20_BACKEND_INFRASTRUCTURE/` — API Specifications, Database Schemas, Authentication, Server Sync, Security
- `21_SAVE_CLOUD_SYSTEM/` — Save Serialization, Cloud Sync, Conflict Resolution, Migration Firmware
- `22_ANALYTICS_TELEMETRY/` — Performance Telemetry, Player Behavior Tracking, Crash Reporting, Privacy Compliance
- `23_MONETIZATION/` — Ethical Cosmetic Store, Battle Pass Specs, Receipt Validation, Compliance

### QA, Testing & Release
- `24_TESTING_QA/` — Automated Unit Tests, Physics Determinism Tests, Visual Regression, Mobile Performance Benchmarks
- `25_PRODUCTION_MANAGEMENT/` — Roadmap, Milestones, Risk Register, Known Issues, Technical Debt Backlog, Glossary
- `26_RELEASE_LIVEOPS/` — App Store / Play Store Requirements, CI/CD Pipelines, Build Targets, Post-Launch Roadmap

---

## 3. Five-Milestone Development Roadmap & Agent Phase Registry

```text
Milestone 1: Engine Foundation & Core Physics (Phases 01 - 20)
Milestone 2: Core Gameplay & Living World Simulation (Phases 21 - 40)
Milestone 3: Content, Biomes, Cosmetics & Progression (Phases 41 - 60)
Milestone 4: Polish, Mobile Optimization & Balancing (Phases 61 - 80)
Milestone 5: Backend, Cloud Save, Store Release & LiveOps (Phases 81 - 100)
```

- [Phase 01: Architecture Rules & Token Discipline](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/Phase_01/README.md)
- [Phase 02: Core Physics & Spherical Kinematics](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/Phase_02/README.md)
- [Phase 03: Jump Physics & Air Control](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/Phase_03/README.md)
- [Phase 04: Ribbon Track Architecture & Curvature Math](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/Phase_04/README.md)
- [Phase 05: Dynamic Camera System & FOV Scaling](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/Phase_05/README.md)

*(Phases 06 to 100 are cataloged in [AGENT_PROMPTS/PHASE_CATALOG.md](file:///e:/Flowstate/FLOWSTATE_MASTER_GUIDE/AGENT_PROMPTS/PHASE_CATALOG.md))*
