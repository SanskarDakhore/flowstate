---
Status: Active
Priority: High
Milestone: 1
---

# Confirmed Features

> Locked features and mechanics that are core to FLOWSTATE's gameplay vision.

## 1. Core Mechanics
- **Spherical Momentum System**: Physics-driven momentum where high speed expands camera FOV and unlocks resonance mechanics.
- **Ribbon Track Generation**: Procedurally generated organic tracks with smooth splines, slope transitions, and curve banking.
- **Living World Growth**: Environment reacts dynamically to player performance; high flow state triggers biome blooming, foliage spawning, and vibrant sky transitions.
- **Dynamic Camera System**: Camera featuring momentum lag, directional tracking, and smooth dynamic FOV scaling.

## 2. Audio & Visuals
- **Resonance Audio System**: Audio stems dynamically blend and layer based on momentum, energy multiplier, and flow state.
- **Luminous Minimalist UI**: Non-intrusive HUD using tokenized glassmorphism, cyan glowing energy meters, and subtle scrim overlays over 3D scenes.
