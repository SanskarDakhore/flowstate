---
Status: Active
Priority: High
Milestone: 1
---

# Rejected Ideas

> Mechanics and design proposals explicitly rejected to preserve core philosophy and prevent design drift.

- **Pay-to-Win Mechanics / Speed Boost Purchases**: REJECTED. FLOWSTATE monetization strictly adheres to cosmetics only. Skill and physics mastery are sole drivers of performance.
- **Aggressive Screen-Space UI Clutter**: REJECTED. No intrusive popups or full-screen telemetry overlays during gameplay; maintain "Luminous Minimalism".
- **Hard-Coded Inline Visual Styles**: REJECTED. Prohibited to maintain design token discipline (`tokens.css`).
