---
Status: Active
Priority: Medium
Milestone: 1
---

# Experimental Features

> Features undergoing prototype testing or design evaluation.

- **Dynamic Wind Drag Vectors**: Evaluating atmospheric wind resistance affecting sphere rotation during high-altitude jumps.
- **Magnetic Energy Ring Boosters**: Prototype rings along the ribbon track that pull the player sphere toward their center line.
- **Seasonal Ecosystem Shifting**: Testing realtime biome transitions from summer valley to autumn forest during single extended runs.
