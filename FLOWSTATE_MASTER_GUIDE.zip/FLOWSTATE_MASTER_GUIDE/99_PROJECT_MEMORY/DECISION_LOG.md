---
Status: Active
Priority: Critical
Milestone: 1
---

# FLOWSTATE Project Decision Log

> Single source of truth for architectural and gameplay decisions. Every AI execution phase must inspect this log before making changes.

## Decision Index

| ID | Title | Status | Date | Decision Summary |
|---|---|---|---|---|
| DEC-001 | GDOS Architecture Framework | Approved | 2026-07-23 | Adopt modular 38-module GDOS v2.0 structure for AI pair programming. |
| DEC-002 | UI Token & Scrim Discipline | Approved | 2026-07-23 | All UI elements must strictly use `tokens.css` variables and `var(--flow-text-scrim)`. |
| DEC-003 | HUD vs DevPanel Isolation | Approved | 2026-07-23 | Strict visual & architectural separation between Player HUD and DevTelemetry. |
| DEC-004 | Core Gameplay Code Lock | Approved | 2026-07-23 | Frontend visual/UI passes must never mutate physics math or collision logic. |
| DEC-005 | Living World Architecture | Approved | 2026-07-23 | Separate Living World Simulation (`04_LIVING_WORLD_SIMULATION`) from Environment Rendering (`05_ENVIRONMENT_RENDERING`). |

---

## Detailed Decision Records

### DEC-001: GDOS Architecture Framework
- **Date**: 2026-07-23
- **Status**: Approved
- **Context**: Large AI projects suffer from context drift when guided by single large prompts.
- **Decision**: Establish `FLOWSTATE_MASTER_GUIDE/` containing 38 domain modules, machine-readable metadata, formal math specs, and 100 modular phase work packages.
- **Impact**: All future code modifications must follow GDOS specs and pass 10-point AI Quality Gates.

### DEC-002: UI Token & Scrim Discipline
- **Date**: 2026-07-23
- **Status**: Approved
- **Context**: Need visual consistency and legibility over vibrant 3D Babylon.js canvas scenes.
- **Decision**: No hardcoded hex values or un-tokenized inline styles in TS/HTML. All UI must dereference variables defined in `frontend/src/ui/styles/tokens.css`.
- **Impact**: Guarantees theme consistency and readable HUD scrims.

### DEC-003: HUD Architecture & Separation of Concerns
- **Date**: 2026-07-23
- **Status**: Approved
- **Context**: Telemetry metrics (FPS, position vectors, model debuggers) pollute player immersion.
- **Decision**: Player HUD (`PlayerHud`) remains minimal and luminous. Technical telemetry stays isolated inside Developer Panel (`DevPanel`).
- **Impact**: Preserves player flow state while maintaining full dev telemetry access.

### DEC-004: Preservation of Gameplay Code
- **Date**: 2026-07-23
- **Status**: Approved
- **Context**: Visual/UI iterations risk introducing regression to sphere momentum and jump physics.
- **Decision**: UI components interact with gameplay strictly via read-only telemetry interfaces and public event buses.
- **Impact**: Zero physics regressions during UI/visual styling passes.
